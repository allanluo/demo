This directory contains some stuff from YAML http://www.yaml.de CSS framework.
The yamldistrib.zip is kept here as reference for future enhancements; only the things actually used are
actually put into git separately.

